#define CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

int main()
{
	int n, k;
	int cnt = 0;
	int i;
	char plug[21] = { NULL };

	scanf("%d %d", &n, &k);

	char name[101] = { NULL };
	for(i = 0; i < k * 2; i++)
		name[i] = getchar();

	plug[0] = name[0];
	// �ʱⰪ n�� �Է¹ޱ�
	i = 1;
	while (cnt != n - 1)
	{
		if (strchr(plug, name[i * 2]) == NULL)
			plug[++ cnt] = name[i * 2];
		i++;
	}

	cnt = 0; //ī��Ʈ �ʱ�ȭ

	for (i; i < k; i++)
	{

	}

	return 0;
}