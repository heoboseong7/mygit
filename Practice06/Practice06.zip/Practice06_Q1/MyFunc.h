#pragma once

extern "C" int Func(int val1, int val2);