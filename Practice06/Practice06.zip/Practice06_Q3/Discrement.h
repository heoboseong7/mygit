#pragma once
extern "C" int Disc(int a, int b, int c);